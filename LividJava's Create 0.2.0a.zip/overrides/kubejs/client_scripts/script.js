// priority: 0

console.info('Hacked the planet! Are you Livid? (Resources Loaded)')

JEIEvents.hideItems(event => {
	// Hide items in JEI here
	// event.hide('minecraft:cobblestone')
})